// Task 1: OBJECT.ASSIGN
// let course = {
//     name : "web programming",
//     score : 92,
// }

// let anotherCourse = {
//     name : "mobile app development",
//     score : 85,
// }

// let finalResult = Object.assign(course, anotherCourse,{grade : "A+"})
// console.log(finalResult)

// TASK 2: NESTED TERNARY OPERATOR

// let student = 16
// let Adult;
// let price;
// let finalResult = (student <= 18) ? (price = 20) : (Adult) ? (price = 30):(price = 30);
// console.log(finalResult)

// TASK:3 FOR OF LOOP
// const names = ["Youtube","Facebook","Instagram","Netflix","Whatsapp"]
// for(const i of names){
//     console.log(i)
// }

// TASK 3 FOR IN LOOP
// const symbols = {
//     yt : "Youtube",
//     fb : "Facebook",
//     ig : "Instagram",
//     wtsapp : "Whatsapp"
// };
// for (const a in symbols){
    // console.log(`key is : ${a} and value is ${symbols[a]}`)
    // console.log("key is :" + a  + " and value is :" + symbols[a])
// }

// TASK 4: ARROW FUNCTION
// Creating a regular function
// const abc = function (){
//     console.log("Hello World")
// }
// abc()

// Converting it to an arrow function
// const abc = ()=>{
//     console.log("Hello World")
// }
// abc();

